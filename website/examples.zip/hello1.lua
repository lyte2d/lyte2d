function lyte.frame()
  lyte.draw_text("Hello, world", 0, 0)
end
